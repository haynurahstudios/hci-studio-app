HAYNURAH CREATIVE INTELLIGENCE — NEW HCI SHARE PACK FOR CHATGPT AND OTHER AIs
Version 1.0 — 13 November 2026

WHAT THIS IS
The new HCI, built from scratch in November 2026 from deep research
(creativity science, AI system design, the AI tools as they stand today,
storytelling and directing craft, human behaviour and emotion). It replaces
the earlier HCI. The old files are kept safe by the owner and are NOT in
this pack — do not mix old and new files in one Project, Gem or Space,
they contradict each other in places.

WHAT IS INSIDE (7 files)
- HCI_New_Blueprint.pdf (28 pp) — the architecture: mission, modes,
  boundaries, how HCI thinks, retrieves, remembers, creates and teaches.
- HCI_New_Operating_Instructions.pdf (37 pp) — the skill itself:
  instructions TO the model operating as HCI.
- HCI_New_Tool_Registry.pdf (19 pp) — every AI image, video and audio
  tool as of November 2026, with capabilities, limits, prices, sources
  and dates. Anything unverified is marked UNVERIFIED.
- HCI_New_Testing.pdf (20 pp) — eight test assignments and the
  evaluation method (profile scoring, never a single number).
- HCI_New_Share_Pack_Install_Guide_for_ChatGPT.pdf (8 pp) — install
  on ChatGPT as a Project (NOT a Custom GPT), step by step, with the
  core rules to paste, the introduction message, and the first test.
- HCI_New_Share_Pack_Install_Guide_for_Other_AIs.pdf (5 pp) — install
  on Gemini (as a Gem) and Perplexity (as a Space), and why Meta AI,
  Grok and Copilot can only be used one chat at a time.
- README.txt — this file.

HOW TO INSTALL (short version)
- ChatGPT: create a Project named "Haynurah Creative Intelligence"
  (NOT a Custom GPT), paste the core rules (ChatGPT guide, Section 4)
  into the Project instructions, upload the files (Free allows 5 files
  per Project — upload the four system documents plus the guide, skip
  the README; paid plans fit all seven), send the introduction message,
  run test T-01. Complete only when T-01 is run and recorded.
- Gemini: create a Gem, same core rules, same four documents, same
  test. Verify file limits on the platform first.
- Perplexity: create a Space, same core rules, same four documents,
  same test. Verify file limits on the platform first.
- Meta AI, Grok, Copilot: no Projects/Gems/Spaces system, so HCI
  cannot be installed there — paste the core rules into one chat and
  use it for that chat only.

WHAT IS NOT IN THE PACK
The eleven Module 1 Academy lessons and the Human Behaviour and
Emotional Expression Encyclopedia — paid material, stays with
Haynurah Studios. You can upload them into your own Project, Gem or
Space yourself.

THE HONESTY RULE
Never claim HCI is ready, tested or proven on a platform until a test
was actually run there. Ready on Muse is not ready on ChatGPT is not
ready on Gemini.

Parent brand: Haynurah Studios.
Tagline: Imagine without limits. Research with intelligence.
Create with direction.

THE LOGO
- hci-logo-no-circle.png — the current HCI logo (neural dome, big 3D
  gold HCI monogram with two gold leaves, water disc with ripples and
  golden reflection, thin orbit arc, no circle). Use this one.
- hci-logo.png — the same logo with the circle, kept as an alternative.
