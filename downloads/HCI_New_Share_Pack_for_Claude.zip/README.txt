HAYNURAH CREATIVE INTELLIGENCE — NEW HCI SHARE PACK FOR CLAUDE
Version 1.0 — 13 November 2026

WHAT THIS IS
The new HCI, built from scratch in November 2026 from deep research
(creativity science, AI system design, the AI tools as they stand today,
storytelling and directing craft, human behaviour and emotion). It replaces
the earlier HCI. The old files are kept safe by the owner and are NOT in
this pack — do not mix old and new files in one Project, they contradict
each other in places.

WHAT IS INSIDE (6 files)
- HCI_New_Blueprint.pdf (28 pp) — the architecture: mission, modes,
  boundaries, how HCI thinks, retrieves, remembers, creates and teaches.
- HCI_New_Operating_Instructions.pdf (37 pp) — the skill itself:
  instructions TO the model operating as HCI.
- HCI_New_Tool_Registry.pdf (19 pp) — every AI image, video and audio
  tool as of November 2026, with capabilities, limits, prices, sources
  and dates. Anything unverified is marked UNVERIFIED.
- HCI_New_Testing.pdf (20 pp) — eight test assignments and the
  evaluation method (profile scoring, never a single number).
- HCI_New_Share_Pack_Install_Guide_for_Claude.pdf (7 pp) — how to
  install it in the Claude app, step by step, with the core rules to
  paste, the introduction message, and the first test (T-01).
- README.txt — this file.

HOW TO INSTALL (short version)
1. In the Claude app, create a new Project named "Haynurah Creative
   Intelligence". Do NOT add these files to the old HCI Project.
2. Paste the core rules (Install Guide, Section 4) into the Project
   instructions.
3. Upload the four system documents.
4. Send the introduction message (Install Guide, Section 5).
5. Run test T-01 (Install Guide, Section 6). The installation is only
   complete when T-01 is run and recorded.

WHAT IS NOT IN THE PACK
The eleven Module 1 Academy lessons and the Human Behaviour and
Emotional Expression Encyclopedia — paid material, stays with
Haynurah Studios. You can upload them into your own Project yourself.

Parent brand: Haynurah Studios.
Tagline: Imagine without limits. Research with intelligence.
Create with direction.

THE LOGO
- hci-logo-no-circle.png — the current HCI logo (neural dome, big 3D
  gold HCI monogram with two gold leaves, water disc with ripples and
  golden reflection, thin orbit arc, no circle). Use this one.
- hci-logo.png — the same logo with the circle, kept as an alternative.
